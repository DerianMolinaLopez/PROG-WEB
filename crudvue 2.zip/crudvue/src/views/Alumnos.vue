<template>
    <div class="Alumonos"> 
        <h1>HOLA MUNDO ALUMNOS</h1>
        <AlumnosVista></AlumnosVista>
    </div>
</template>
<script>
import AlumnosVista from '../components/AlumnosLista.vue'
      export default{
        name:"Alumnos",
        components:{AlumnosVista},
        data(){
            return {

         }
        },
        mounted(){

        },
        methods(){

        },
      }
</script>